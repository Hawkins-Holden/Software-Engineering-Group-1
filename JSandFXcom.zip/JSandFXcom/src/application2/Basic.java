package application2;

//import java.util.*;
//import java.io.*;

public class Basic
{
	
	String zip = new String();
	
	public void setZip(String newZip)
	{
		this.zip = newZip;
	}
	public String getZip()
	{
		return this.zip;
	}
}